#include "log_config.h"

// your endpoint
const char LOG_ENDPOINT[] = "";
// your access key id
const char ACCESS_KEY_ID[] = "";
// your access key secret
const char ACCESS_KEY_SECRET[] = "";
// your project name
const char PROJECT_NAME[] = "";
// your logstore name
const char LOGSTORE_NAME[] = "";
